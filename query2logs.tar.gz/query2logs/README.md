This directory should only have QueryVisualization code

Python modules that this depends on:
tornado-4.2.1
impyla
requests-2.7.0
sortedcontainers-0.9.6
flask
futures-3.0.3

The source code for these modules should all be in /modules


Invocation:
python tornadoserver.py

Server IP address:
198.18.55.217 (this may change)

